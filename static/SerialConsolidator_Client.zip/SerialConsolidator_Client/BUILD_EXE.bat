@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python
) else (
    set PYCMD=py
)

echo Installing pyinstaller, requests, tkcalendar...
%PYCMD% -m pip install --quiet pyinstaller requests tkcalendar

echo Building SerialConsolidator.exe ...
%PYCMD% -m PyInstaller --onefile --windowed --name SerialConsolidator serial_consolidator_app.py

echo.
echo Done. Find SerialConsolidator.exe inside the "dist" folder.
echo The first time each person runs it, it will ask for the server
echo address once and remember it next to the .exe from then on.
pause
