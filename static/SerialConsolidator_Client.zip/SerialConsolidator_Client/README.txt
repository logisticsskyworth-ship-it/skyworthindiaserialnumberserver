SERIAL NUMBER CONSOLIDATOR - Desktop App (Client)
==================================================
For Skyworth India Electronics warehouse serial number tracking.

This is the CLIENT app. Everyone on the team runs this. It talks to a
central server over the internet, so team members can be anywhere - they
no longer need to be on the same office network or shared drive.

You (the admin) need to deploy the server once first - see the separate
"SerialConsolidator_Server" package and its README_DEPLOY.md. Once that's
live, come back here to hand this client folder out to the team.

FIRST-TIME SETUP FOR EACH TEAM MEMBER
--------------------------------------
1. Copy this whole folder to their PC, e.g.:
   C:\Skyworth\SerialConsolidator\
2. Double-click RUN_ME.bat
   - It finds Python (or installs it if winget is available), installs the
     required packages (requests, tkcalendar), and launches the app.
3. The FIRST time it runs, it asks for the "Server address":
   https://skyworthindiaserialnumberserver.onrender.com
   Paste it in and click "Save & Continue". It's remembered after that -
   they won't be asked again on that PC.
4. Log in with the username/password your admin created for you.

EVERYTHING ELSE WORKS THE SAME AS BEFORE
------------------------------------------
- Login accounts, Admin Panel, duplicate review, invoice quantity limits,
  batch details, search/filter/export - all identical to the original
  single-PC version. The only difference is that data now lives on the
  central server instead of a local file, so every team member (anywhere)
  sees the same shared master list in real time.
- Deleting serial numbers still requires admin authorization for non-admin
  users (checked by the server, not just the app).
- Admin Panel (visible to admin accounts only) still creates logins,
  resets passwords, and activates/deactivates users - server-side now, so
  it applies to everyone immediately.

EXPORTING
---------
Master Data / Search tab -> set filters (optional) -> "Export Filtered
Range to Excel..." downloads a fresh .xlsx from the server to your PC,
exactly like before.

CHANGING THE SERVER ADDRESS
------------------------------
Click "Change server address" on the login screen, or delete
client_config.json in this folder and restart the app.

MAKING IT A DOUBLE-CLICKABLE APP (optional)
--------------------------------------------
After RUN_ME.bat has worked at least once, double-click BUILD_EXE.bat to
build SerialConsolidator.exe in this folder. From then on, just double
click that .exe - no Python commands needed. It remembers the server
address next to itself.

TROUBLESHOOTING
----------------
"Could not reach the server" - check the PC's internet connection and
that the server address was typed correctly (must start with https://).
If the server is on a free hosting tier, it may take 20-30 seconds to
"wake up" after being idle - just wait and try again.

"Session expired" - just log back in when prompted; nothing is lost.
