"""
Thin HTTP client for the Serial Number Consolidator server.
Mirrors the shape of the old core.py functions but talks to the hosted
API instead of a local SQLite file, so the GUI code barely has to change.
"""
import json
import os
import sys

import requests

if getattr(sys, "frozen", False):
    # Running as a PyInstaller .exe - keep the config next to the .exe itself,
    # not the temp folder PyInstaller unpacks into (which changes every run).
    _APP_DIR = os.path.dirname(sys.executable)
else:
    _APP_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_PATH = os.path.join(_APP_DIR, "client_config.json")
APP_DIR = _APP_DIR
TIMEOUT = 60


class ApiError(Exception):
    """Raised for any failed call - message is safe to show in a messagebox."""
    pass


class ApiClient:
    def __init__(self):
        self.base_url = ""
        self.token = None
        self.username = None
        self.role = None
        self._load_config()

    # --- setup ---

    def _load_config(self):
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r") as f:
                    data = json.load(f)
                self.base_url = (data.get("server_url") or "").rstrip("/")
            except Exception:
                self.base_url = ""

    def has_server_url(self):
        return bool(self.base_url)

    def save_server_url(self, url):
        self.base_url = url.strip().rstrip("/")
        with open(CONFIG_PATH, "w") as f:
            json.dump({"server_url": self.base_url}, f)

    # --- internals ---

    def _headers(self):
        h = {}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _url(self, path):
        return f"{self.base_url}{path}"

    def _request(self, method, path, **kwargs):
        import time
        last_err = None
        for attempt in range(2):
            try:
                r = requests.request(method, self._url(path), headers=self._headers(),
                                      timeout=TIMEOUT, **kwargs)
                break
            except requests.exceptions.ConnectionError as e:
                last_err = e
                if attempt == 0:
                    time.sleep(5)  # server may be waking up from sleep (free hosting tiers)
                    continue
                raise ApiError(f"Could not reach the server at:\n{self.base_url}\n\n"
                                "Checked twice (waited for a possible cold start). Make sure:\n"
                                "- The address is correct and starts with https://\n"
                                "- This PC has internet access\n"
                                "- The server is actually running (open the address in a browser -\n"
                                "  you should see a small 'status: ok' message)")
            except requests.exceptions.Timeout:
                raise ApiError("The server took too long to respond (over 60s). It may be waking up "
                                "from sleep - please try again in a moment.")
            except requests.exceptions.RequestException as e:
                raise ApiError(f"Network error: {e}")

        if r.status_code == 401:
            raise ApiError("SESSION_EXPIRED")
        if r.status_code >= 400:
            try:
                detail = r.json().get("detail", r.text)
            except Exception:
                detail = r.text
            raise ApiError(str(detail))
        return r

    # --- auth ---

    def login(self, username, password):
        r = self._request("POST", "/login", json={"username": username, "password": password})
        data = r.json()
        self.token = data["token"]
        self.username = data["username"]
        self.role = data["role"]
        return {"id": data.get("id"), "username": self.username, "role": self.role}

    def logout(self):
        self.token = None
        self.username = None
        self.role = None

    def verify_any_admin_password(self, password):
        r = self._request("POST", "/verify-admin-password", json={"password": password})
        return r.json()["ok"]

    # --- invoices ---

    def upsert_invoice(self, invoice_number, quantity=None, model="", vehicle_number="",
                        customer_name="", entry_date="", storage_location="", warehouse=""):
        self._request("POST", "/invoices", json={
            "invoice_number": invoice_number, "quantity": quantity, "model": model,
            "vehicle_number": vehicle_number, "customer_name": customer_name,
            "entry_date": entry_date, "storage_location": storage_location, "warehouse": warehouse,
        })

    def get_invoice_and_used(self, invoice_number):
        r = self._request("GET", f"/invoices/{requests.utils.quote(invoice_number, safe='')}")
        data = r.json()
        return data["invoice"], data["used"]

    # --- records ---

    def add_record(self, serial_number, model="", invoice_number="", sheet_name="Manual Entry",
                    source="manual", vehicle_number="", customer_name="", entry_date="",
                    storage_location="", warehouse=""):
        r = self._request("POST", "/records", json={
            "serial_number": serial_number, "model": model, "invoice_number": invoice_number,
            "vehicle_number": vehicle_number, "customer_name": customer_name,
            "entry_date": entry_date, "storage_location": storage_location, "warehouse": warehouse,
            "sheet_name": sheet_name, "source": source,
        })
        data = r.json()
        return data["status"], data["info"]

    def delete_record(self, record_id, admin_password=None):
        params = {}
        if admin_password:
            params["admin_password"] = admin_password
        self._request("DELETE", f"/records/{record_id}", params=params)

    # --- excel upload ---

    def import_excel_file(self, filepath):
        with open(filepath, "rb") as f:
            files = {"file": (os.path.basename(filepath), f,
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
            r = self._request("POST", "/upload-excel", files=files)
        return r.json()

    # --- duplicates ---

    def get_pending_duplicates(self):
        r = self._request("GET", "/duplicates")
        return r.json()["rows"]

    def resolve_duplicate(self, dup_id, action, admin_password=None):
        self._request("POST", f"/duplicates/{dup_id}/resolve",
                       json={"action": action, "admin_password": admin_password})

    # --- models / warehouses (dropdown lookup lists) ---

    def list_models(self):
        r = self._request("GET", "/models")
        return r.json()["rows"]

    def add_model(self, name):
        self._request("POST", "/models", json={"name": name})

    def list_warehouses(self):
        r = self._request("GET", "/warehouses")
        return r.json()["rows"]

    def add_warehouse(self, name):
        self._request("POST", "/warehouses", json={"name": name})

    def import_lookup_lists(self, filepath):
        with open(filepath, "rb") as f:
            files = {"file": (os.path.basename(filepath), f,
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
            r = self._request("POST", "/lookup-lists/import", files=files)
        return r.json()

    # --- search / stats / export ---

    def search_master(self, query="", date_from="", date_to=""):
        r = self._request("GET", "/search", params={"q": query, "date_from": date_from, "date_to": date_to})
        return r.json()["rows"]

    def stats(self):
        r = self._request("GET", "/stats")
        return r.json()

    def export_master(self, out_path, query="", date_from="", date_to=""):
        r = self._request("GET", "/export", params={"q": query, "date_from": date_from, "date_to": date_to})
        with open(out_path, "wb") as f:
            f.write(r.content)
        return out_path

    # --- admin: users ---

    def list_users(self):
        r = self._request("GET", "/users")
        return r.json()["rows"]

    def create_user(self, username, password, role="user"):
        self._request("POST", "/users", json={"username": username, "password": password, "role": role})

    def reset_password(self, username, new_password):
        self._request("POST", f"/users/{requests.utils.quote(username, safe='')}/reset-password",
                       json={"new_password": new_password})

    def set_user_active(self, username, active):
        self._request("POST", f"/users/{requests.utils.quote(username, safe='')}/active",
                       json={"active": active})


api = ApiClient()
