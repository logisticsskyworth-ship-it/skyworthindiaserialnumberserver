"""
Serial Number Consolidator - Desktop App (Client)
Skyworth India Electronics - Warehouse Operations

Run with:  python serial_consolidator_app.py
Requires:  Python 3.8+ (tkinter is built in), requests, tkcalendar
           (pip install requests tkcalendar)

This client talks to a central server over the internet (see api.py /
client_config.json). Everyone on the team runs this same app and logs in
with their own username - all entries land in one shared database that you
can search, review, and export from.

All network refreshes run on a background thread and hand results back to
the UI via .after(0, ...) - keeps the window responsive, no freezing while
waiting on the server.
"""
import os
import sys
import threading
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from api import api, ApiError, APP_DIR

try:
    from tkcalendar import Calendar
    HAS_CALENDAR = True
except ImportError:
    HAS_CALENDAR = False

APP_TITLE = "Serial Number Consolidator - Skyworth Warehouse"
TODAY = datetime.now().strftime("%Y-%m-%d")

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------
PRIMARY_DARK = "#123B54"
PRIMARY = "#1B6FA8"
PRIMARY_LIGHT = "#EAF3FA"
ACCENT_GREEN = "#2E9E5B"
ACCENT_GREEN_DARK = "#22794A"
ACCENT_RED = "#C0392B"
ACCENT_RED_DARK = "#9E2E20"
ACCENT_AMBER = "#C77D00"
BG_APP = "#F3F6F9"
CARD_BG = "#FFFFFF"
TEXT_DARK = "#1B1F23"
TEXT_MUTED = "#5B6672"
BORDER = "#D8DFE6"
ROW_EVEN = "#FFFFFF"
ROW_ODD = "#F5F8FB"

FONT_NORMAL = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 14, "bold")
FONT_LABEL = ("Segoe UI", 10)
FONT_MONO = ("Consolas", 10)

BACKUP_INTERVAL_MS = 15 * 60 * 1000  # 15 minutes
BACKUP_KEEP = 20


def make_button(parent, text, command, kind="primary", **kw):
    """Consistent, color-coded buttons with a hover effect."""
    palette = {
        "primary": (PRIMARY, "white", PRIMARY_DARK),
        "success": (ACCENT_GREEN, "white", ACCENT_GREEN_DARK),
        "danger": (ACCENT_RED, "white", ACCENT_RED_DARK),
        "neutral": ("#E4E9EE", TEXT_DARK, "#CCD6DF"),
    }
    bg, fg, hover_bg = palette.get(kind, palette["primary"])
    defaults = dict(font=FONT_BOLD, bg=bg, fg=fg, activebackground=hover_bg, activeforeground=fg,
                     bd=0, relief="flat", padx=14, pady=7, cursor="hand2")
    defaults.update(kw)
    btn = tk.Button(parent, text=text, command=command, **defaults)
    btn.bind("<Enter>", lambda e: btn.configure(bg=hover_bg))
    btn.bind("<Leave>", lambda e: btn.configure(bg=bg))
    return btn


def fit_combobox(combo, values, minw=18, maxw=48):
    """Widen a combobox (and its dropdown) to fit the longest value instead
    of truncating long model/warehouse names."""
    if values:
        w = max(minw, min(maxw, max(len(v) for v in values) + 2))
    else:
        w = minw
    combo.configure(width=w)


class DateField(tk.Frame):
    """An Entry + a small calendar-picker button. Keeps the field freely
    editable/clearable (unlike tkcalendar's DateEntry, which can't be blank),
    while giving a proper calendar popup to pick a date from."""

    def __init__(self, parent, textvariable, width=12, **kw):
        super().__init__(parent, bg=kw.pop("bg", CARD_BG))
        self.var = textvariable
        self.entry = tk.Entry(self, textvariable=self.var, font=FONT_NORMAL, width=width,
                               relief="solid", bd=1, highlightthickness=0)
        self.entry.pack(side="left")
        self.cal_btn = tk.Button(self, text="📅", font=("Segoe UI", 9), bd=0, bg="#E4E9EE",
                                  activebackground="#D3DAE1", cursor="hand2", padx=4,
                                  command=self.open_calendar)
        self.cal_btn.pack(side="left", padx=(3, 0))

    def open_calendar(self):
        if not HAS_CALENDAR:
            messagebox.showinfo("Calendar unavailable",
                                 "The calendar picker needs the 'tkcalendar' package.\n"
                                 "Run RUN_ME.bat again to install it, or type the date manually "
                                 "as YYYY-MM-DD.")
            return
        popup = tk.Toplevel(self)
        popup.title("Pick a date")
        popup.resizable(False, False)
        popup.transient(self.winfo_toplevel())

        current = self.var.get().strip()
        kwargs = dict(date_pattern="yyyy-mm-dd", font=FONT_NORMAL,
                       background=PRIMARY, foreground="white",
                       headersbackground=PRIMARY_LIGHT, selectbackground=PRIMARY)
        try:
            if current:
                y, m, d = [int(p) for p in current.split("-")]
                cal = Calendar(popup, year=y, month=m, day=d, **kwargs)
            else:
                cal = Calendar(popup, **kwargs)
        except Exception:
            cal = Calendar(popup, **kwargs)
        cal.pack(padx=10, pady=10)

        def pick():
            self.var.set(cal.get_date())
            popup.destroy()

        btn_row = tk.Frame(popup)
        btn_row.pack(pady=(0, 10))
        make_button(btn_row, "Select", pick, kind="primary").pack(side="left", padx=4)
        make_button(btn_row, "Clear", lambda: (self.var.set(""), popup.destroy()),
                    kind="neutral").pack(side="left", padx=4)

        popup.update_idletasks()
        px = self.winfo_rootx()
        py = self.winfo_rooty() + self.winfo_height()
        popup.geometry(f"+{px}+{py}")
        popup.grab_set()


class ServerSetupDialog(tk.Toplevel):
    """Shown once (first run) to capture the server address."""

    def __init__(self, master):
        super().__init__(master)
        self.ok = False
        self.title("Server Setup - " + APP_TITLE)
        self.geometry("460x220")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.on_cancel)
        self.configure(bg=CARD_BG)

        tk.Label(self, text="Connect to Server", font=FONT_TITLE,
                 bg=CARD_BG, fg=PRIMARY_DARK).pack(pady=(20, 2))
        tk.Label(self, text="Enter the server address given to you (only needed once).",
                 font=FONT_NORMAL, bg=CARD_BG, fg=TEXT_MUTED, wraplength=420, justify="center").pack(pady=(0, 15))

        self.url_var = tk.StringVar(value=api.base_url or "https://")
        entry = tk.Entry(self, textvariable=self.url_var, font=("Segoe UI", 11), width=40,
                          relief="solid", bd=1)
        entry.pack(pady=5, ipady=3)
        entry.bind("<Return>", lambda e: self.on_save())

        self.error_label = tk.Label(self, text="", font=("Segoe UI", 9), bg=CARD_BG, fg=ACCENT_RED)
        self.error_label.pack(pady=(6, 0))

        btn_frame = tk.Frame(self, bg=CARD_BG)
        btn_frame.pack(pady=15)
        make_button(btn_frame, "Save & Continue", self.on_save, kind="primary").pack(side="left", padx=5)
        make_button(btn_frame, "Exit", self.on_cancel, kind="neutral").pack(side="left", padx=5)

        self.update_idletasks()
        w, h = 460, 220
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.grab_set()
        self.lift()
        entry.focus_set()

    def on_save(self):
        url = self.url_var.get().strip()
        if not url.startswith("http://") and not url.startswith("https://"):
            self.error_label.config(text="Address must start with https:// (or http://)")
            return
        api.save_server_url(url)
        self.ok = True
        self.grab_release()
        self.destroy()

    def on_cancel(self):
        self.ok = False
        self.grab_release()
        self.destroy()


class LoginDialog(tk.Toplevel):
    """Modal login window shown before the main app appears."""

    def __init__(self, master):
        super().__init__(master)
        self.result_user = None

        self.title("Login - " + APP_TITLE)
        self.geometry("380x300")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.on_cancel)
        self.configure(bg=CARD_BG)

        tk.Label(self, text="Serial Number Consolidator", font=FONT_TITLE,
                 bg=CARD_BG, fg=PRIMARY_DARK).pack(pady=(20, 2))
        tk.Label(self, text="Please log in to continue", font=FONT_NORMAL,
                 bg=CARD_BG, fg=TEXT_MUTED).pack(pady=(0, 15))

        form = tk.Frame(self, bg=CARD_BG)
        form.pack(pady=5)

        tk.Label(form, text="Username", font=FONT_LABEL, bg=CARD_BG).grid(row=0, column=0, sticky="w", pady=4)
        self.username_var = tk.StringVar()
        user_entry = tk.Entry(form, textvariable=self.username_var, font=("Segoe UI", 11), width=24,
                               relief="solid", bd=1)
        user_entry.grid(row=0, column=1, pady=4, padx=8, ipady=2)

        tk.Label(form, text="Password", font=FONT_LABEL, bg=CARD_BG).grid(row=1, column=0, sticky="w", pady=4)
        self.password_var = tk.StringVar()
        pass_entry = tk.Entry(form, textvariable=self.password_var, font=("Segoe UI", 11), width=24, show="*",
                               relief="solid", bd=1)
        pass_entry.grid(row=1, column=1, pady=4, padx=8, ipady=2)

        self.error_label = tk.Label(self, text="", font=("Segoe UI", 9), bg=CARD_BG, fg=ACCENT_RED, wraplength=340)
        self.error_label.pack(pady=(6, 0))

        btn_frame = tk.Frame(self, bg=CARD_BG)
        btn_frame.pack(pady=15)
        make_button(btn_frame, "Login", self.on_login, kind="primary").pack(side="left", padx=5)
        make_button(btn_frame, "Exit", self.on_cancel, kind="neutral").pack(side="left", padx=5)

        tk.Button(self, text="Change server address", font=("Segoe UI", 8), bd=0, fg=PRIMARY, bg=CARD_BG,
                  cursor="hand2", command=self.on_change_server).pack(pady=(0, 8))

        user_entry.bind("<Return>", lambda e: pass_entry.focus_set())
        pass_entry.bind("<Return>", lambda e: self.on_login())

        self.update_idletasks()
        w, h = 380, 300
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

        self.grab_set()
        self.lift()
        self.attributes("-topmost", True)
        self.after(250, lambda: self.attributes("-topmost", False))
        self.focus_force()
        user_entry.focus_set()

    def on_change_server(self):
        dlg = ServerSetupDialog(self)
        self.wait_window(dlg)

    def on_login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get()
        if not username or not password:
            self.error_label.config(text="Enter both username and password.")
            return
        try:
            user = api.login(username, password)
        except ApiError as e:
            msg = str(e)
            self.error_label.config(text="Incorrect username or password." if "credentials" in msg.lower()
                                     or "401" in msg or "Incorrect" in msg else msg)
            self.password_var.set("")
            return
        self.result_user = user
        self.grab_release()
        self.destroy()

    def on_cancel(self):
        self.result_user = None
        self.grab_release()
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1300x740")
        self.minsize(1050, 620)
        self.configure(bg=BG_APP)
        self.withdraw()  # hide main window until login succeeds

        self._setup_style()

        if not api.has_server_url():
            dlg = ServerSetupDialog(self)
            self.wait_window(dlg)
            if not dlg.ok:
                self.destroy()
                sys.exit(0)

        self.current_user = self._do_login()
        if not self.current_user:
            self.destroy()
            sys.exit(0)

        self.user_name = self.current_user["username"]
        self.is_admin = self.current_user["role"] == "admin"

        # id -> display text, in the order shown in the "recent" list (newest first)
        self.manual_recent_ids = []
        self.models_list = []
        self.warehouses_list = []
        self.backup_dir = os.path.join(APP_DIR, "backups")

        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self._build_ui()

        self.update_idletasks()
        w, h = 1300, 740
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{max(x, 0)}+{max(y, 0)}")
        self.deiconify()
        self.lift()
        self.attributes("-topmost", True)
        self.after(250, lambda: self.attributes("-topmost", False))
        self.focus_force()

        # First data load happens after the window is already visible, in the
        # background, so the app never sits frozen on a splash screen.
        self.refresh_lookup_lists()
        self.refresh_all()

        # Local backups: one shortly after startup, then on a timer, then on close.
        self.after(8000, self._scheduled_backup)

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background=BG_APP, borderwidth=0)
        style.configure("TNotebook.Tab", font=FONT_BOLD, padding=(18, 10),
                         background="#DCE6EF", foreground=PRIMARY_DARK)
        style.map("TNotebook.Tab",
                  background=[("selected", PRIMARY)],
                  foreground=[("selected", "white")])
        style.configure("TFrame", background=BG_APP)
        style.configure("Treeview", font=FONT_NORMAL, rowheight=27, background=CARD_BG,
                        fieldbackground=CARD_BG, foreground=TEXT_DARK, borderwidth=0)
        style.configure("Treeview.Heading", font=FONT_BOLD, background=PRIMARY_DARK, foreground="white",
                        relief="flat")
        style.map("Treeview.Heading", background=[("active", PRIMARY_DARK)])
        style.map("Treeview", background=[("selected", PRIMARY)], foreground=[("selected", "white")])
        style.configure("TCombobox", padding=4)

    def _do_login(self):
        while True:
            dlg = LoginDialog(self)
            self.wait_window(dlg)
            if dlg.result_user:
                return dlg.result_user
            return None

    # ---------- Async helper (keeps the UI thread free) ----------

    def _async(self, work, on_done=None, on_error=None):
        def runner():
            try:
                result = work()
            except ApiError as e:
                self.after(0, lambda: (on_error(e) if on_error else self._handle_api_error(e)))
                return
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Error", str(e)))
                return
            if on_done:
                self.after(0, lambda: on_done(result))
        threading.Thread(target=runner, daemon=True).start()

    def _handle_api_error(self, e):
        """Central place to react to a failed API call. Always called on the
        main thread (via .after)."""
        if str(e) == "SESSION_EXPIRED":
            messagebox.showwarning("Session expired", "Your session expired - please log in again.")
            user = self._do_login()
            if not user:
                self.destroy()
                sys.exit(0)
            self.current_user = user
            self.user_name = user["username"]
            self.is_admin = user["role"] == "admin"
            return
        messagebox.showerror("Error", str(e))

    def on_close(self):
        try:
            self._run_backup(silent=True)
        except Exception:
            pass
        self.destroy()

    # ---------- Local backups ----------

    def _run_backup(self, silent=True):
        os.makedirs(self.backup_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = os.path.join(self.backup_dir, f"backup_{ts}.xlsx")
        try:
            api.export_master(out_path)
        except ApiError as e:
            if not silent:
                self.after(0, lambda: messagebox.showerror("Backup failed", str(e)))
            return False
        try:
            files = sorted(
                (f for f in os.listdir(self.backup_dir) if f.startswith("backup_") and f.endswith(".xlsx")),
                reverse=True,
            )
            for old in files[BACKUP_KEEP:]:
                os.remove(os.path.join(self.backup_dir, old))
        except Exception:
            pass
        if not silent:
            self.after(0, lambda: messagebox.showinfo("Backup complete", f"Local backup saved to:\n{out_path}"))
        return True

    def _scheduled_backup(self):
        threading.Thread(target=self._run_backup, kwargs={"silent": True}, daemon=True).start()
        self.after(BACKUP_INTERVAL_MS, self._scheduled_backup)

    def on_backup_now(self):
        threading.Thread(target=self._run_backup, kwargs={"silent": False}, daemon=True).start()

    # ---------- Model / Warehouse lookup lists ----------

    def refresh_lookup_lists(self):
        def work():
            return api.list_models(), api.list_warehouses()
        self._async(work, on_done=self._apply_lookup_lists)

    def _apply_lookup_lists(self, result):
        self.models_list, self.warehouses_list = result
        if hasattr(self, "model_combo"):
            self.model_combo["values"] = self.models_list
            fit_combobox(self.model_combo, self.models_list)
        if hasattr(self, "warehouse_combo"):
            self.warehouse_combo["values"] = self.warehouses_list
            fit_combobox(self.warehouse_combo, self.warehouses_list)
        if hasattr(self, "models_listbox"):
            self.models_listbox.delete(0, "end")
            for m in self.models_list:
                self.models_listbox.insert("end", m)
        if hasattr(self, "warehouses_listbox"):
            self.warehouses_listbox.delete(0, "end")
            for w in self.warehouses_list:
                self.warehouses_listbox.insert("end", w)

    def _on_tab_changed(self, event=None):
        # Keep dropdown lists fresh as people move around the app - if an
        # admin added a new model/warehouse, everyone picks it up the next
        # time they touch a tab (runs in the background, no UI freeze).
        self.refresh_lookup_lists()

    # ---------- UI construction ----------

    def _build_ui(self):
        header = tk.Frame(self, bg=PRIMARY_DARK)
        header.pack(fill="x", side="top")
        tk.Label(header, text="  Serial Number Consolidator", font=("Segoe UI", 15, "bold"),
                 bg=PRIMARY_DARK, fg="white", pady=12).pack(side="left")
        tk.Label(header, text="Skyworth Warehouse Operations  ", font=FONT_NORMAL,
                 bg=PRIMARY_DARK, fg="#BFD8EA").pack(side="right")

        self.status_var = tk.StringVar(value="  Loading...")
        status_bar = tk.Label(self, textvariable=self.status_var, anchor="w",
                               bg=PRIMARY, fg="white", font=FONT_BOLD, padx=12, pady=7)
        status_bar.pack(fill="x", side="top")

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)
        notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)

        self.manual_tab = ttk.Frame(notebook)
        self.duplicates_tab = ttk.Frame(notebook)
        self.master_tab = ttk.Frame(notebook)

        notebook.add(self.manual_tab, text="Manual Entry")
        notebook.add(self.duplicates_tab, text="Duplicates Review")
        notebook.add(self.master_tab, text="Master Data / Search")

        self.notebook = notebook
        self._build_manual_tab()
        self._build_duplicates_tab()
        self._build_master_tab()

        if self.is_admin:
            self.admin_tab = ttk.Frame(notebook)
            notebook.add(self.admin_tab, text="Admin Panel")
            self._build_admin_tab()

    def _build_manual_tab(self):
        frame = self.manual_tab

        batch_box = tk.LabelFrame(frame, text="Batch Details (stays fixed until you change it)",
                                   font=FONT_BOLD, padx=15, pady=12, bg=CARD_BG, fg=PRIMARY_DARK)
        batch_box.pack(fill="x", padx=15, pady=(15, 8))

        self.batch_vars = {
            "Invoice Number": tk.StringVar(),
            "Invoice Quantity": tk.StringVar(),
            "Model": tk.StringVar(),
            "Warehouse": tk.StringVar(),
            "Vehicle Number": tk.StringVar(),
            "Customer Name": tk.StringVar(),
            "Storage Location": tk.StringVar(),
            "Date": tk.StringVar(value=TODAY),
        }
        grid = tk.Frame(batch_box, bg=CARD_BG)
        grid.pack(fill="x")
        labels = list(self.batch_vars.keys())
        for i, label in enumerate(labels):
            r, c = divmod(i, 3)
            tk.Label(grid, text=label, font=FONT_LABEL, bg=CARD_BG).grid(
                row=r * 2, column=c, sticky="w", padx=8, pady=(4, 0))
            if label == "Model":
                self.model_combo = ttk.Combobox(grid, textvariable=self.batch_vars[label],
                                                 values=self.models_list, state="readonly", width=30)
                self.model_combo.grid(row=r * 2 + 1, column=c, sticky="w", padx=8, pady=(0, 8))
            elif label == "Warehouse":
                self.warehouse_combo = ttk.Combobox(grid, textvariable=self.batch_vars[label],
                                                     values=self.warehouses_list, state="readonly", width=22)
                self.warehouse_combo.grid(row=r * 2 + 1, column=c, sticky="w", padx=8, pady=(0, 8))
            elif label == "Date":
                DateField(grid, self.batch_vars[label], width=14, bg=CARD_BG).grid(
                    row=r * 2 + 1, column=c, sticky="w", padx=8, pady=(0, 8))
            else:
                entry = tk.Entry(grid, textvariable=self.batch_vars[label], font=FONT_NORMAL, width=22,
                                  relief="solid", bd=1)
                entry.grid(row=r * 2 + 1, column=c, sticky="w", padx=8, pady=(0, 8), ipady=2)

        btn_row = tk.Frame(batch_box, bg=CARD_BG)
        btn_row.pack(anchor="w", pady=(4, 0))
        make_button(btn_row, "Set / Update Batch Details", self.on_set_batch, kind="primary").pack(side="left")
        make_button(btn_row, "Refresh Model/Warehouse Lists", self.refresh_lookup_lists,
                    kind="neutral").pack(side="left", padx=(10, 0))

        self.active_invoice_label = tk.Label(batch_box, text="No active invoice set yet.",
                                              font=("Segoe UI", 10, "italic"), fg=TEXT_MUTED, bg=CARD_BG)
        self.active_invoice_label.pack(anchor="w", pady=(8, 0))

        add_box = tk.LabelFrame(frame, text="Add Serial Number", font=FONT_BOLD, padx=15, pady=12,
                                 bg=CARD_BG, fg=PRIMARY_DARK)
        add_box.pack(fill="x", padx=15, pady=8)

        row = tk.Frame(add_box, bg=CARD_BG)
        row.pack(fill="x")
        tk.Label(row, text="Serial Number *", font=("Segoe UI", 11), bg=CARD_BG).pack(side="left")
        self.serial_var = tk.StringVar()
        serial_entry = tk.Entry(row, textvariable=self.serial_var, font=("Segoe UI", 12), width=30,
                                 relief="solid", bd=1)
        serial_entry.pack(side="left", padx=10, ipady=3)
        serial_entry.bind("<Return>", lambda e: self.on_manual_add())
        make_button(row, "Add Serial Number", self.on_manual_add, kind="success").pack(side="left", padx=8)
        self.serial_entry_widget = serial_entry

        self.manual_feedback = tk.Label(add_box, text="", font=("Segoe UI", 11), bg=CARD_BG)
        self.manual_feedback.pack(anchor="w", pady=(8, 0))

        recent_header = tk.Frame(frame, bg=BG_APP)
        recent_header.pack(fill="x", padx=15, pady=(0, 0))
        tk.Label(recent_header, text="Added this session (newest first - select + Delete to undo a mistake)",
                 font=("Segoe UI", 10, "italic"), bg=BG_APP, fg=TEXT_MUTED).pack(side="left")

        recent_box = tk.Frame(frame, bg=CARD_BG, highlightbackground=BORDER, highlightthickness=1)
        recent_box.pack(fill="both", expand=True, padx=15, pady=(4, 15))
        self.manual_recent = tk.Listbox(recent_box, height=10, font=FONT_MONO, bd=0, relief="flat",
                                         highlightthickness=0)
        self.manual_recent.pack(fill="both", expand=True, side="left", padx=(6, 0), pady=6)
        scroll = tk.Scrollbar(recent_box, command=self.manual_recent.yview)
        scroll.pack(side="left", fill="y", pady=6)
        self.manual_recent.config(yscrollcommand=scroll.set)
        btns_col = tk.Frame(recent_box, bg=CARD_BG)
        btns_col.pack(side="left", padx=10, pady=6, anchor="n")
        make_button(btns_col, "Delete Selected", self.on_delete_recent, kind="danger").pack(fill="x", pady=(0, 6))
        make_button(btns_col, "Clear List", self.on_clear_recent, kind="neutral").pack(fill="x")

        serial_entry.focus_set()

    def on_clear_recent(self):
        if not self.manual_recent_ids:
            return
        if not messagebox.askyesno("Clear list", "Clear this session's list? (Does not delete any saved records.)"):
            return
        self.manual_recent.delete(0, "end")
        self.manual_recent_ids.clear()

    def _build_duplicates_tab(self):
        frame = self.duplicates_tab
        tk.Label(frame, text="Duplicates you chose to leave pending (instead of approving immediately)\n"
                              "sit here for later review.",
                 font=FONT_NORMAL, justify="left", bg=BG_APP).pack(anchor="w", padx=15, pady=(15, 5))

        columns = ("serial", "new_model", "new_invoice", "new_sheet", "existing_model",
                   "existing_invoice", "existing_sheet")
        headers = ("Serial Number", "New Model", "New Invoice", "New Source", "Existing Model",
                   "Existing Invoice", "Existing Source")

        self.dup_tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="extended")
        for col, head in zip(columns, headers):
            self.dup_tree.heading(col, text=head)
            self.dup_tree.column(col, width=140, anchor="w")
        self.dup_tree.pack(fill="both", expand=True, padx=15, pady=10)
        self.dup_tree.tag_configure("odd", background=ROW_ODD)
        self.dup_tree.tag_configure("even", background=ROW_EVEN)

        btn_frame = tk.Frame(frame, bg=BG_APP)
        btn_frame.pack(pady=(0, 15))
        make_button(btn_frame, "Discard New (keep existing)", lambda: self.resolve_selected("discard"),
                    kind="neutral").pack(side="left", padx=5)
        make_button(btn_frame, "Replace Existing With New", lambda: self.resolve_selected("replace"),
                    kind="primary").pack(side="left", padx=5)
        make_button(btn_frame, "Keep Both (add as new record)", lambda: self.resolve_selected("keep_both"),
                    kind="success").pack(side="left", padx=5)
        make_button(btn_frame, "Refresh", self.refresh_duplicates, kind="neutral").pack(side="left", padx=20)

    def _build_master_tab(self):
        frame = self.master_tab
        top = tk.Frame(frame, bg=BG_APP)
        top.pack(fill="x", padx=15, pady=(15, 5))

        tk.Label(top, text="Search:", font=FONT_NORMAL, bg=BG_APP).grid(row=0, column=0, sticky="w")
        self.search_var = tk.StringVar()
        search_entry = tk.Entry(top, textvariable=self.search_var, font=FONT_NORMAL, width=20,
                                 relief="solid", bd=1)
        search_entry.grid(row=0, column=1, padx=(6, 16), ipady=2)
        search_entry.bind("<Return>", lambda e: self.refresh_master())

        tk.Label(top, text="Date from:", font=FONT_NORMAL, bg=BG_APP).grid(row=0, column=2, sticky="w")
        self.date_from_var = tk.StringVar()
        DateField(top, self.date_from_var, width=12, bg=BG_APP).grid(row=0, column=3, padx=(6, 16))

        tk.Label(top, text="Date to:", font=FONT_NORMAL, bg=BG_APP).grid(row=0, column=4, sticky="w")
        self.date_to_var = tk.StringVar()
        DateField(top, self.date_to_var, width=12, bg=BG_APP).grid(row=0, column=5, padx=(6, 16))

        make_button(top, "Apply Filter", self.refresh_master, kind="primary").grid(row=0, column=6, padx=5)
        make_button(top, "Clear", self.clear_search, kind="neutral").grid(row=0, column=7, padx=5)

        top2 = tk.Frame(frame, bg=BG_APP)
        top2.pack(fill="x", padx=15, pady=(0, 10))
        make_button(top2, "Export Filtered Range to Excel...", self.on_export, kind="primary").pack(
            side="right", padx=5)
        make_button(top2, "Backup Now (to this PC)", self.on_backup_now, kind="neutral").pack(
            side="right", padx=5)
        make_button(top2, "Delete Selected", self.on_delete_selected, kind="danger").pack(side="right", padx=5)

        columns = ("id", "serial", "model", "invoice", "vehicle", "customer", "storage", "warehouse",
                   "date", "sheet", "scan_time")
        headers = ("ID", "Serial Number", "Model", "Invoice Number", "Vehicle Number",
                   "Customer Name", "Storage Location", "Warehouse", "Date", "Sheet Name", "Scan Time")
        tree_frame = tk.Frame(frame, bg=BG_APP)
        tree_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        self.master_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="extended")
        widths = (50, 140, 110, 120, 110, 140, 120, 110, 95, 170, 150)
        for col, head, w in zip(columns, headers, widths):
            self.master_tree.heading(col, text=head)
            self.master_tree.column(col, width=w, anchor="w")
        self.master_tree.tag_configure("odd", background=ROW_ODD)
        self.master_tree.tag_configure("even", background=ROW_EVEN)
        hbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.master_tree.xview)
        vbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.master_tree.yview)
        self.master_tree.configure(xscrollcommand=hbar.set, yscrollcommand=vbar.set)
        self.master_tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

    # ---------- Actions ----------

    def refresh_all(self):
        self.refresh_status()
        self.refresh_duplicates()
        self.refresh_master()

    def refresh_status(self):
        self._async(lambda: api.stats(), on_done=self._apply_status)

    def _apply_status(self, data):
        role_label = "Admin" if self.is_admin else "User"
        self.status_var.set(
            f"  Logged in as: {self.user_name} ({role_label})   |   Active serial numbers: {data['active']}   |   "
            f"Pending duplicate reviews: {data['pending']}   |   Server: {api.base_url}"
        )

    # --- Manual entry / batch details ---

    def on_set_batch(self):
        invoice_number = self.batch_vars["Invoice Number"].get().strip()
        if not invoice_number:
            messagebox.showwarning("Invoice number required", "Enter an Invoice Number before setting batch details.")
            return

        qty_str = self.batch_vars["Invoice Quantity"].get().strip()
        quantity = None
        if qty_str:
            try:
                quantity = int(qty_str)
                if quantity <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning("Invalid quantity", "Invoice Quantity must be a positive whole number.")
                return

        model = self.batch_vars["Model"].get().strip()
        vehicle_number = self.batch_vars["Vehicle Number"].get().strip()
        customer_name = self.batch_vars["Customer Name"].get().strip()
        entry_date = self.batch_vars["Date"].get().strip()
        storage_location = self.batch_vars["Storage Location"].get().strip()
        warehouse = self.batch_vars["Warehouse"].get().strip()

        def work():
            api.upsert_invoice(invoice_number, quantity=quantity, model=model, vehicle_number=vehicle_number,
                                customer_name=customer_name, entry_date=entry_date,
                                storage_location=storage_location, warehouse=warehouse)

        def done(_):
            self._refresh_active_invoice_label()
            self.serial_entry_widget.focus_set()

        self._async(work, on_done=done)

    def _refresh_active_invoice_label(self):
        invoice_number = self.batch_vars["Invoice Number"].get().strip()
        if not invoice_number:
            self.active_invoice_label.config(text="No active invoice set yet.")
            return

        def work():
            return api.get_invoice_and_used(invoice_number)

        def done(result):
            inv, used = result
            if inv and inv.get("quantity"):
                remaining = inv["quantity"] - used
                self.active_invoice_label.config(
                    text=f"Active Invoice: {invoice_number}   |   Quantity: {inv['quantity']}   |   "
                         f"Used: {used}   |   Remaining: {remaining}",
                    fg=(ACCENT_RED if remaining <= 0 else PRIMARY_DARK))
            else:
                self.active_invoice_label.config(
                    text=f"Active Invoice: {invoice_number}   |   No quantity limit set   |   Used so far: {used}",
                    fg=TEXT_MUTED)

        self._async(work, on_done=done)

    def on_manual_add(self):
        serial = self.serial_var.get().strip()
        if not serial:
            self.manual_feedback.config(text="Serial Number is required.", fg=ACCENT_RED)
            return

        invoice_number = self.batch_vars["Invoice Number"].get().strip()
        model = self.batch_vars["Model"].get().strip()
        warehouse = self.batch_vars["Warehouse"].get().strip()
        vehicle_number = self.batch_vars["Vehicle Number"].get().strip()
        customer_name = self.batch_vars["Customer Name"].get().strip()
        entry_date = self.batch_vars["Date"].get().strip()
        storage_location = self.batch_vars["Storage Location"].get().strip()

        self.manual_feedback.config(text="Adding...", fg=TEXT_MUTED)

        def work():
            return api.add_record(
                serial, model=model, invoice_number=invoice_number,
                sheet_name="Manual Entry", source="manual",
                vehicle_number=vehicle_number, customer_name=customer_name, entry_date=entry_date,
                storage_location=storage_location, warehouse=warehouse,
            )

        def done(result):
            status, info = result
            if status == "added":
                self.manual_feedback.config(text=f"Added: {serial}", fg=ACCENT_GREEN_DARK)
                self.manual_recent.insert(0, f"[Added] {serial}  |  Inv: {invoice_number}  |  {model}")
                self.manual_recent_ids.insert(0, info)
                self.serial_var.set("")
            elif status == "flagged_duplicate":
                self.manual_recent.insert(0, f"[Duplicate - pending approval] {serial}  |  Inv: {invoice_number}")
                self.manual_recent_ids.insert(0, None)
                self.serial_var.set("")
                self._handle_duplicate_now(serial, info)
            elif status == "exceeds_quantity":
                self.manual_feedback.config(
                    text=f"Exceeds the invoice quantity. ({info['used']}/{info['quantity']} already used for "
                         f"invoice {info['invoice_number']})",
                    fg=ACCENT_RED)
            else:
                self.manual_feedback.config(text="Serial number is required.", fg=ACCENT_RED)

            self._refresh_active_invoice_label()
            self.refresh_all()
            self.serial_entry_widget.focus_set()

        self._async(work, on_done=done)

    def _authorize_admin(self, action_desc="perform this action"):
        """Returns (authorized: bool, admin_password_used: str|None).
        Admins are authorized with no password. Non-admins must supply the
        correct admin password, which is forwarded to the server so it can
        double-check the action is legitimate. (Single blocking call - a
        deliberate button press, not a background refresh, so it's fine.)"""
        if self.is_admin:
            return True, None
        pwd = simpledialog.askstring(
            "Admin authorization required",
            f"{action_desc} requires admin authorization.\n"
            "Enter the admin password to continue:",
            show="*", parent=self
        )
        if pwd is None:
            return False, None
        try:
            ok = api.verify_any_admin_password(pwd)
        except ApiError as e:
            self._handle_api_error(e)
            return False, None
        if ok:
            return True, pwd
        messagebox.showerror("Incorrect password", "That admin password is not correct.")
        return False, None

    def _handle_duplicate_now(self, serial, info):
        """Manual-entry duplicates are resolved right away (with admin
        approval) instead of silently sitting in the review queue."""
        dup_id = info.get("dup_id")
        existing_model = info.get("existing_model") or "-"
        existing_invoice = info.get("existing_invoice") or "-"
        existing_sheet = info.get("existing_sheet") or "-"
        msg = (f"Serial '{serial}' already exists in the system.\n\n"
               f"Existing record  ->  Model: {existing_model}   Invoice: {existing_invoice}   "
               f"Source: {existing_sheet}\n\n"
               "This requires admin approval before it can be entered.\n\n"
               "Yes = Replace the existing record with this new entry\n"
               "No = Keep both as separate records\n"
               "Cancel = Leave it pending in Duplicates Review for later")
        choice = messagebox.askyesnocancel("Duplicate Serial Number", msg)
        if choice is None:
            self.manual_feedback.config(text=f"'{serial}' is a duplicate - left pending in Duplicates Review.",
                                         fg=ACCENT_AMBER)
            return
        action = "replace" if choice else "keep_both"
        authorized, pwd = self._authorize_admin(f"Adding duplicate serial '{serial}'")
        if not authorized:
            self.manual_feedback.config(
                text=f"'{serial}' duplicate not approved - left pending in Duplicates Review.", fg=ACCENT_AMBER)
            return

        def work():
            api.resolve_duplicate(dup_id, action, admin_password=pwd)

        def done(_):
            self.manual_feedback.config(
                text=f"Duplicate '{serial}' resolved "
                     f"({'replaced existing' if action == 'replace' else 'kept both'}).",
                fg=ACCENT_GREEN_DARK)
            self.refresh_all()

        self._async(work, on_done=done)

    def on_delete_recent(self):
        sel = self.manual_recent.curselection()
        if not sel:
            messagebox.showwarning("No selection", "Select an entry in the list first.")
            return
        idx = sel[0]
        record_id = self.manual_recent_ids[idx]
        if record_id is None:
            messagebox.showinfo("Nothing to delete", "That entry was a duplicate flag, not a saved record.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete this serial number entry?"):
            return
        authorized, pwd = self._authorize_admin("Deleting a serial number")
        if not authorized:
            return

        def work():
            api.delete_record(record_id, admin_password=pwd)

        def done(_):
            self.manual_recent.delete(idx)
            del self.manual_recent_ids[idx]
            self.refresh_all()

        self._async(work, on_done=done)

    # --- Duplicates ---

    def refresh_duplicates(self):
        self._async(lambda: api.get_pending_duplicates(), on_done=self._apply_duplicates)

    def _apply_duplicates(self, rows):
        for row in self.dup_tree.get_children():
            self.dup_tree.delete(row)
        for i, rec in enumerate(rows):
            (dup_id, serial, new_model, new_invoice, new_sheet, new_date, source, added_by,
             existing_id, ex_model, ex_invoice, ex_sheet, ex_date) = rec
            self.dup_tree.insert("", "end", iid=str(dup_id), values=(
                serial, new_model, new_invoice, new_sheet, ex_model, ex_invoice, ex_sheet
            ), tags=("even" if i % 2 == 0 else "odd",))

    def resolve_selected(self, action):
        selected = self.dup_tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select one or more rows in the table first.")
            return
        authorized, pwd = self._authorize_admin("Resolving a duplicate")
        if not authorized:
            return

        def work():
            for iid in selected:
                api.resolve_duplicate(int(iid), action, admin_password=pwd)

        self._async(work, on_done=lambda _: self.refresh_all())

    # --- Master data ---

    def refresh_master(self):
        query, date_from, date_to = self.search_var.get(), self.date_from_var.get(), self.date_to_var.get()
        self._async(lambda: api.search_master(query, date_from, date_to), on_done=self._apply_master)

    def _apply_master(self, rows):
        for row in self.master_tree.get_children():
            self.master_tree.delete(row)
        for i, rec in enumerate(rows):
            self.master_tree.insert("", "end", iid=str(rec[0]), values=rec,
                                     tags=("even" if i % 2 == 0 else "odd",))

    def clear_search(self):
        self.search_var.set("")
        self.date_from_var.set("")
        self.date_to_var.set("")
        self.refresh_master()

    def on_delete_selected(self):
        selected = self.master_tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select one or more rows to delete.")
            return
        if not messagebox.askyesno("Confirm delete", f"Delete {len(selected)} selected record(s)?"):
            return
        authorized, pwd = self._authorize_admin("Deleting a serial number")
        if not authorized:
            return

        def work():
            for iid in selected:
                api.delete_record(int(iid), admin_password=pwd)

        self._async(work, on_done=lambda _: self.refresh_all())

    def on_export(self):
        out_path = filedialog.asksaveasfilename(
            title="Save export as...", defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfile="Serial_Numbers_Export.xlsx"
        )
        if not out_path:
            return
        query, date_from, date_to = self.search_var.get(), self.date_from_var.get(), self.date_to_var.get()

        def work():
            api.export_master(out_path, query, date_from, date_to)

        def done(_):
            messagebox.showinfo("Export complete", f"Exported to:\n{out_path}")

        self._async(work, on_done=done)

    # ---------- Admin Panel (locked - admins only) ----------

    def _build_admin_tab(self):
        frame = self.admin_tab
        canvas = tk.Canvas(frame, bg=BG_APP, highlightthickness=0)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG_APP)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        tk.Label(inner, text="Admin Panel - create logins, manage the Model/Warehouse dropdown lists,\n"
                              "and reset passwords. Only an admin account can see this tab.",
                 font=FONT_NORMAL, justify="left", bg=BG_APP).pack(anchor="w", padx=15, pady=(15, 5))

        # --- Users ---
        create_box = tk.LabelFrame(inner, text="Create Username / Password", font=FONT_BOLD, padx=15, pady=12,
                                    bg=CARD_BG, fg=PRIMARY_DARK)
        create_box.pack(fill="x", padx=15, pady=8)

        grid = tk.Frame(create_box, bg=CARD_BG)
        grid.pack(fill="x")

        tk.Label(grid, text="Username", font=FONT_LABEL, bg=CARD_BG).grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.new_username_var = tk.StringVar()
        tk.Entry(grid, textvariable=self.new_username_var, font=FONT_NORMAL, width=20, relief="solid", bd=1).grid(
            row=0, column=1, padx=6, pady=4, ipady=2)

        tk.Label(grid, text="Password", font=FONT_LABEL, bg=CARD_BG).grid(row=0, column=2, sticky="w", padx=6, pady=4)
        self.new_password_var = tk.StringVar()
        tk.Entry(grid, textvariable=self.new_password_var, font=FONT_NORMAL, width=20, show="*",
                  relief="solid", bd=1).grid(row=0, column=3, padx=6, pady=4, ipady=2)

        tk.Label(grid, text="Role", font=FONT_LABEL, bg=CARD_BG).grid(row=0, column=4, sticky="w", padx=6, pady=4)
        self.new_role_var = tk.StringVar(value="user")
        role_menu = ttk.Combobox(grid, textvariable=self.new_role_var, values=["user", "admin"],
                                  state="readonly", width=10)
        role_menu.grid(row=0, column=5, padx=6, pady=4)

        make_button(create_box, "Create User", self.on_create_user, kind="success").pack(anchor="w", pady=(8, 0))

        list_box = tk.LabelFrame(inner, text="Existing Users", font=FONT_BOLD, padx=15, pady=12,
                                  bg=CARD_BG, fg=PRIMARY_DARK)
        list_box.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        columns = ("username", "role", "created", "active")
        headers = ("Username", "Role", "Created", "Active")
        self.users_tree = ttk.Treeview(list_box, columns=columns, show="headings", selectmode="browse", height=8)
        for col, head, w in zip(columns, headers, (160, 80, 160, 70)):
            self.users_tree.heading(col, text=head)
            self.users_tree.column(col, width=w, anchor="w")
        self.users_tree.tag_configure("odd", background=ROW_ODD)
        self.users_tree.tag_configure("even", background=ROW_EVEN)
        self.users_tree.pack(fill="both", expand=True, side="left")

        btns = tk.Frame(list_box, bg=CARD_BG)
        btns.pack(side="left", padx=10, anchor="n")
        make_button(btns, "Reset Password", self.on_reset_password, kind="neutral").pack(fill="x", pady=4)
        make_button(btns, "Deactivate User", lambda: self.on_set_user_active(False), kind="danger").pack(
            fill="x", pady=4)
        make_button(btns, "Activate User", lambda: self.on_set_user_active(True), kind="success").pack(
            fill="x", pady=4)
        make_button(btns, "Refresh", self.refresh_users, kind="neutral").pack(fill="x", pady=4)

        # --- Models & Warehouses ---
        lookup_box = tk.LabelFrame(inner, text="Manage Models & Warehouses (shown in every team member's dropdowns)",
                                    font=FONT_BOLD, padx=15, pady=12, bg=CARD_BG, fg=PRIMARY_DARK)
        lookup_box.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        cols_frame = tk.Frame(lookup_box, bg=CARD_BG)
        cols_frame.pack(fill="both", expand=True)

        model_col = tk.Frame(cols_frame, bg=CARD_BG)
        model_col.pack(side="left", fill="both", expand=True, padx=(0, 10))
        tk.Label(model_col, text="Models", font=FONT_BOLD, bg=CARD_BG, fg=PRIMARY_DARK).pack(anchor="w")
        add_model_row = tk.Frame(model_col, bg=CARD_BG)
        add_model_row.pack(fill="x", pady=4)
        self.new_model_var = tk.StringVar()
        tk.Entry(add_model_row, textvariable=self.new_model_var, font=FONT_NORMAL, relief="solid", bd=1).pack(
            side="left", fill="x", expand=True, ipady=2)
        make_button(add_model_row, "Add", self.on_add_model, kind="success").pack(side="left", padx=(6, 0))
        self.models_listbox = tk.Listbox(model_col, height=10, font=FONT_NORMAL, relief="solid", bd=1)
        self.models_listbox.pack(fill="both", expand=True, pady=(4, 0))

        wh_col = tk.Frame(cols_frame, bg=CARD_BG)
        wh_col.pack(side="left", fill="both", expand=True, padx=(10, 0))
        tk.Label(wh_col, text="Warehouses", font=FONT_BOLD, bg=CARD_BG, fg=PRIMARY_DARK).pack(anchor="w")
        add_wh_row = tk.Frame(wh_col, bg=CARD_BG)
        add_wh_row.pack(fill="x", pady=4)
        self.new_warehouse_var = tk.StringVar()
        tk.Entry(add_wh_row, textvariable=self.new_warehouse_var, font=FONT_NORMAL, relief="solid", bd=1).pack(
            side="left", fill="x", expand=True, ipady=2)
        make_button(add_wh_row, "Add", self.on_add_warehouse, kind="success").pack(side="left", padx=(6, 0))
        self.warehouses_listbox = tk.Listbox(wh_col, height=10, font=FONT_NORMAL, relief="solid", bd=1)
        self.warehouses_listbox.pack(fill="both", expand=True, pady=(4, 0))

        make_button(lookup_box, "Import Models/Warehouses from Excel...", self.on_import_lookup_lists,
                    kind="neutral").pack(anchor="w", pady=(10, 0))

        self.refresh_users()
        self.refresh_lookup_lists()

    def refresh_users(self):
        self._async(lambda: api.list_users(), on_done=self._apply_users)

    def _apply_users(self, rows):
        for row in self.users_tree.get_children():
            self.users_tree.delete(row)
        for i, (uid, username, role, created_at, is_active) in enumerate(rows):
            self.users_tree.insert("", "end", iid=username, values=(
                username, role, created_at, "Yes" if is_active else "No"
            ), tags=("even" if i % 2 == 0 else "odd",))

    def on_create_user(self):
        username = self.new_username_var.get().strip()
        password = self.new_password_var.get()
        role = self.new_role_var.get().strip() or "user"

        if not username or not password:
            messagebox.showwarning("Missing details", "Enter both a username and a password.")
            return
        if len(password) < 6:
            messagebox.showwarning("Weak password", "Use a password with at least 6 characters.")
            return

        def work():
            api.create_user(username, password, role=role)

        def done(_):
            messagebox.showinfo("User created", f"'{username}' can now log in with the password you set.")
            self.new_username_var.set("")
            self.new_password_var.set("")
            self.new_role_var.set("user")
            self.refresh_users()

        def on_error(e):
            messagebox.showerror("Could not create user", str(e))

        self._async(work, on_done=done, on_error=on_error)

    def _selected_username(self):
        sel = self.users_tree.selection()
        if not sel:
            messagebox.showwarning("No selection", "Select a user in the list first.")
            return None
        return sel[0]

    def on_reset_password(self):
        username = self._selected_username()
        if not username:
            return
        new_pwd = simpledialog.askstring("Reset password", f"New password for '{username}':",
                                          show="*", parent=self)
        if not new_pwd:
            return
        if len(new_pwd) < 6:
            messagebox.showwarning("Weak password", "Use a password with at least 6 characters.")
            return
        confirm_pwd = simpledialog.askstring("Confirm password", "Re-enter the new password:",
                                              show="*", parent=self)
        if new_pwd != confirm_pwd:
            messagebox.showerror("Mismatch", "Passwords did not match. Password not changed.")
            return

        def work():
            api.reset_password(username, new_pwd)

        def done(_):
            messagebox.showinfo("Password reset", f"Password for '{username}' has been updated.")

        self._async(work, on_done=done)

    def on_set_user_active(self, active):
        username = self._selected_username()
        if not username:
            return
        if username == self.user_name and not active:
            messagebox.showwarning("Not allowed", "You can't deactivate the account you're currently using.")
            return

        def work():
            api.set_user_active(username, active)

        self._async(work, on_done=lambda _: self.refresh_users())

    def on_add_model(self):
        name = self.new_model_var.get().strip()
        if not name:
            return

        def work():
            api.add_model(name)

        def done(_):
            self.new_model_var.set("")
            self.refresh_lookup_lists()

        self._async(work, on_done=done)

    def on_add_warehouse(self):
        name = self.new_warehouse_var.get().strip()
        if not name:
            return

        def work():
            api.add_warehouse(name)

        def done(_):
            self.new_warehouse_var.set("")
            self.refresh_lookup_lists()

        self._async(work, on_done=done)

    def on_import_lookup_lists(self):
        filepath = filedialog.askopenfilename(
            title="Select Models/Warehouses Excel file", filetypes=[("Excel files", "*.xlsx *.xlsm")]
        )
        if not filepath:
            return

        def work():
            return api.import_lookup_lists(filepath)

        def done(summary):
            messagebox.showinfo("Import complete",
                                 f"Added {summary.get('models_added', 0)} model row(s) and "
                                 f"{summary.get('warehouses_added', 0)} warehouse row(s) "
                                 "(duplicates in the file are ignored automatically).")
            self.refresh_lookup_lists()

        self._async(work, on_done=done)


if __name__ == "__main__":
    app = App()
    app.mainloop()
