@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python
    goto :found
)
where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py
    goto :found
)

echo Python was not found on this PC.
where winget >nul 2>nul
if %errorlevel%==0 (
    echo Attempting to install Python via winget...
    winget install -e --id Python.Python.3.12
    set PYCMD=python
    goto :found
)

echo.
echo Could not find or auto-install Python.
echo Please install it manually from https://www.python.org/downloads/
echo IMPORTANT: on the first install screen, tick "Add python.exe to PATH"
echo Then double-click RUN_ME.bat again.
pause
exit /b 1

:found
echo Installing required packages (requests, tkcalendar)...
%PYCMD% -m pip install --quiet requests tkcalendar

echo Starting Serial Number Consolidator...
%PYCMD% serial_consolidator_app.py
pause
